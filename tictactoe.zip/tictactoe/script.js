let table = document.querySelector("table");

let array = [];
let count = 1;

let x = "X";
let o = "O";

let player1, player2;
let point1 = 0;
let point2 = 0;

// player1 = prompt("player1 i daxil et", "X");
// player2 = prompt("player2 ni daxil et" , "O");
player1 = "X";
player2 = "O";

Start()

function Start(){

    document.querySelector("#show").innerHTML = player1 +  " : " + point1;
    document.querySelector("#show2").innerHTML = player2 + " : " + point2;
    Arr();
    Table();
}

function Table(){
    let tbl = ``;

    for(let i = 0; i<3; i++){
        tbl += `<tr>`;

        for(let j = 0;j<3; j++){
            tbl+= `<td onclick="Click(${i},${j})"> ${array[i][j] == undefined ? " " : array[i][j] } </td>`;
        }
        tbl+= `</tr>`;
    }
    table.innerHTML = tbl;
}

function Arr(){
    for(let i = 0 ; i<3; i++){
        array[i] = [];
    }
    console.log(array);
}

function Click(i,j){
if(array[i][j] == undefined){
    if(count%2==0){
        array[i][j] = o;
    }else{
        array[i][j] = x;
    }
    count++;
    Table();
   setTimeout(Check, 250);
}

}

function Check(){
    let hH = document.querySelector(".beraber");
    for(let i = 0 ;i<3;i++){
        if(array[i][0] !=undefined && array[i][0] == array[i][1] && array[i][1] == array[i][2]){
           Finish(array[i][0]);
        }
    }

    for(let i = 0 ;i<3;i++){
        if(array[0][i] !=undefined && array[0][i] == array[1][i] && array[1][i] == array[2][i]){
           Finish(array[0][i]);
        }
    }

    if(array[0][0] !=undefined && array[0][0] == array[1][1] && array[1][1] == array[2][2]){
        Finish(array[0][0]);
    }

    if(array[0][2] !=undefined && array[0][2] == array[1][1] && array[1][1] == array[2][0]){
        Finish(array[0][2]);
    }

    if(count == 10){
        hH.innerHTML = "Hech-heche!";
        Start();
        count=1;
    }

}

function Winner(par){
  return  par == x ? player1 + " Won" : player2 + " Won";
}

function Score(par){
  return  par == x ? point1++ : point2++;
}

function Finish(par){    
alert(Winner(par));
Score(par);
Start();
count = 1;
}